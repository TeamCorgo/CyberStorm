 


#reputationgivenlist .summaryinfo {
margin-left:5px;
padding-left:10px;
}
#reputationgivenlist .summaryinfo .iteminfo {
	margin-left:10px;
}
 